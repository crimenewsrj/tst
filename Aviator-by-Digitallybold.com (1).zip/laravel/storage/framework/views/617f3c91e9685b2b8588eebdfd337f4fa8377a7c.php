<!-- partial:partials/_footer.html -->
<footer class="footer">
    <div class="container-fluid d-flex justify-content-between">
        <span class="text-muted d-block text-center text-sm-start d-sm-inline-block">Copyright © <?php echo e(env('APP_NAME')); ?>

            2022-23</span>
        <span class="float-none float-sm-end mt-1 mt-sm-0 text-end"><a
                href="https://www.thixpro.com" target="_blank">from Thixpro</a> </span>
    </div>
</footer>
<!-- partial -->
<?php /**PATH /home/luckysho/test.luckyshots.in/laravel/resources/views/include/admin/footer.blade.php ENDPATH**/ ?>