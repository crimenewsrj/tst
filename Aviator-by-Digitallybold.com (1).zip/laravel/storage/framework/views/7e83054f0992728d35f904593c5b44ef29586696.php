
<?php $__env->startSection('content'); ?>
    <div class="active" id="via-email">
        <form class="register-form row w-75" style="margin: 100px auto 0 auto; color: white !important;">
            <h2>Level Managements</h2>
            <?php echo csrf_field(); ?>
            <div class="col-md-12 col-12">
                <p>Total Player: <?php echo e($users); ?></p>
            </div>
            <div class="col-md-4">
                Level 1 List
                <table class="table table-striped" style="color: white;">
                    <tr>
                        <th style="color: white;" style="color: white;" style="color: white;">userid</th>
                        <th style="color: white;" style="color: white;" style="color: white;">Name</th>
                    </tr>
                    <?php if(count($level1) > 0): ?>
                        <?php $__currentLoopData = $level1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->id); ?></td>
                                <td><?php echo e($item->name); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="2">No user found!</td>
                        </tr>
                    <?php endif; ?>
                </table>
            </div>
            <div class="col-md-4">
                Level 2 List
                <table class="table table-striped" style="color: white;">
                    <tr>
                        <th style="color: white;" style="color: white;" style="color: white;">userid</th>
                        <th style="color: white;" style="color: white;" style="color: white;">Name</th>
                    </tr>
                <?php if(count($level2) > 0): ?>
                        <?php $__currentLoopData = $level2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $subitem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->id); ?></td>
                                    <td><?php echo e($item->name); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="2">No user found!</td>
                        </tr>
                    <?php endif; ?>
                </table>
            </div>
            <div class="col-md-4">
                Level 3 List
                <table class="table table-striped" style="color: white;">
                    <tr>
                        <th style="color: white;" style="color: white;" style="color: white;">userid</th>
                        <th style="color: white;" style="color: white;" style="color: white;">Name</th>
                    </tr>
                    <?php if(count($level3) > 0): ?>
                        <?php $__currentLoopData = $level3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $subitem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->id); ?></td>
                                    <td><?php echo e($item->name); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="2">No user found!</td>
                        </tr>
                    <?php endif; ?>
                </table>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.usergame2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u558340823/domains/thixpro.in/public_html/aviator/laravel/resources/views/level_management.blade.php ENDPATH**/ ?>