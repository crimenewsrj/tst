
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="page-header">
            <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white me-2">
                    <i class="mdi mdi-home"></i>
                </span> User Edit
            </h3>
            
        </div>
        <div class="row">
            <div class="col-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">User edit</h4>
                        <form class="forms-sample" id="changepassword">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="userid" value="<?php echo e(admin('id')); ?>">
                            <div class="form-group">
                                <label for="name">Name</label>
                                <input type="text" class="form-control" id="name" name="name" placeholder="Name"
                                    value="<?php echo e($user->name); ?>">
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="text" class="form-control" id="email" name="email" placeholder="Email"
                                    value="<?php echo e($user->email); ?>">
                            </div>
                            <div class="form-group">
                                <label for="email">Mobile</label>
                                <input type="text" class="form-control" id="email" name="emai`l" placeholder="Mobile no."
                                    value="<?php echo e($user->mobile); ?>">
                            </div>
                            <button type="submit" class="btn btn-gradient-primary me-2">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- content-wrapper ends -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $("#changepassword").on('submit', function(e) {
            e.preventDefault();
        });
        $("#changepassword").validate({
            submitHandler: function(form) {
                apex("POST", "<?php echo e(url('admin/api/changepassword')); ?>", new FormData(form), form,
                    "/admin/dashboard", "#");
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.admindashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u558340823/domains/thixpro.in/public_html/aviator/laravel/resources/views/admin/useredit.blade.php ENDPATH**/ ?>