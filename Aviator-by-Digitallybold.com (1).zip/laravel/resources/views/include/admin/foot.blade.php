<script src="{{ asset('vendor/jquery/jquery-3.6.1.min.js') }}"></script>
<!-- plugins:js -->
<script src="/aviatoradmin/assets/vendors/js/vendor.bundle.base.js"></script>
<!-- endinject -->
<script src="{{ asset('vendor/jquery-validation/dist/jquery.validate.min.js') }}"></script>
<!-- Plugin js for this page -->
<script src="/aviatoradmin/assets/vendors/chart.js/Chart.min.js"></script>
<script src="/aviatoradmin/assets/js/jquery.cookie.js" type="text/javascript"></script>
<!-- End plugin js for this page -->
<!-- inject:js -->
<script src="/aviatoradmin/assets/js/off-canvas.js"></script>
<script src="/aviatoradmin/assets/js/hoverable-collapse.js"></script>
<script src="/aviatoradmin/assets/js/misc.js"></script>
<!-- endinject -->
<!-- Custom js for this page -->
<script src="/aviatoradmin/assets/js/dashboard.js"></script>
<script src="/aviatoradmin/assets/js/todolist.js"></script>
<script src="{{ asset('vendor/izitoast/js/iziToast.min.js') }}"></script>
<script src="/js/appcustomize.js"></script>
<!-- End custom js for this page -->
